let quizData = [
    {
        question : "음악은 어머니는?",
        a : "헨델",
        b : "비발디",
        c : "베토벤",
        d : "모짜르트",
        correct : "a"
    },
    {
        question : "음악의 아버지는?",
        a : "바흐",
        b : "비발디",
        c : "베토벤",
        d : "모짜르트",
        correct : "a"
    },
    {
        question : "이 사이트는 소프트웨어공학 과제로 만든 사이트 입니다. 사이트의 이름은?",
        a : "무밥",
        b : "아름다운 이별",
        c : "좋은 멜로디",
        d : "MUBIND",
        correct : "d"
    },
    // {
    //     question : "내가 가장 먹고 싶은 디저트은?",
    //     a : "마카롱",
    //     b : "초코케이크",
    //     c : "크로플",
    //     d : "다",
    //     correct : "d"
    // },
    // {
    //     question : "피아노는 (   )을 개량하여 만들어진 악기이다.",
    //     a : "바이올린",
    //     b : "실로폰",
    //     c : "오르간",
    //     d : "첼로",
    //     correct : "c"
    // },
    // {
    //     question : "음악 용어 (   )는 독주자가 화려한 기교를 뽐내는 부분을 뜻한다.",
    //     a : "샤콘느(Chaconne)",
    //     b : "오콘트",
    //     c : "셔콘느",
    //     d : "알리아",
    //     correct : "a"
    // },
    // {
    //     question : "이 사이트는 소프트웨어공학 과제로 만든 사이트 입니다. 사이트의 이름은?",
    //     a : "무밥",
    //     b : "아름다운 이별",
    //     c : "좋은 멜로디",
    //     d : "MUBIND",
    //     correct : "d"
    // },
    // {
    //     question : "내가 가장 먹고 싶은 저녁은?",
    //     a : "제육볶음",
    //     b : "간장찜닭",
    //     c : "알리오올리오",
    //     d : "샐러드",
    //     correct : "b"
    // },
]
const questionEl = document.getElementById("question")
const quiz_container = document.getElementsByClassName("quiz_container")
const question_container = document.getElementsByClassName("question_container")
const a_textEl = document.getElementById("a_text");
const b_textEl = document.getElementById("b_text");
const c_textEl = document.getElementById("c_text");
const d_textEl = document.getElementById("d_text");
const e_textEl = document.getElementById("e_text");
const f_textEl = document.getElementById("f_text");
const g_textEl = document.getElementById("g_text");
const h_textEl = document.getElementById("h_text");
const quiz = document.getElementById("quiz") //id 값이 quiz인 것을 들고오겠다.
const button = document.getElementById("submit")

const answersEls = document.querySelectorAll('.answer')

let cur = 0;
let score = 0;
// 버튼 이벤트 부여하는함수에서 퀴즈 데이터.length 랑 cur이랑 숫자 세보면 오류의 원인파악 가능 ->> score 숫자를 수정함

//퀴즈 불러오는 함수
function loadQuiz(){
    questionEl.innerText = quizData[cur].question
    a_textEl.innerText = quizData[cur].a
    b_textEl.innerText = quizData[cur].b
    c_textEl.innerText = quizData[cur].c
    d_textEl.innerText = quizData[cur].d
    e_textEl.innerText = quizData[cur].e
    f_textEl.innerText = quizData[cur].f
    g_textEl.innerText = quizData[cur].g
    h_textEl.innerText = quizData[cur].h
}
function removeQuiz(){
    questionEl.style.display="none"
    a_textEl.style.display="none" 
    b_textEl.style.display="none" 
    c_textEl.style.display="none"
    d_textEl.style.display="none"
    e_textEl.style.display="none"
    f_textEl.style.display="none"
    g_textEl.style.display="none"
    h_textEl.style.display="none"
}

//무슨 답 골랐는지 찾아오는 함수
function getSelected(){
    let selected = undefined;
    answersEls.forEach(ele => {
        if(ele.checked){
            selected = ele.id
        }
    })
    return selected
}

//답 체크 해제하는 함수
// function deSelectAnswer(){
//     answersEls.forEach(element => {
//         element.checked = false
//     });
// }
// $("input:checkbox[id='quizDate']").prop("checked", true);
 // 모든 체크박스 해제
//  $("input[name=allNonChk]").click(function(){
//     $(":checkbox").prop("checked",false);
// });

const checkAll = (target) => {
    const isChecked = target.checked;
     
    document.querySelectorAll(`.list_box input`)
      .forEach(el => {
         el.checked = isChecked;
      }); 
   }

let abcde = 0;

//버튼에 이벤트 부여
button.addEventListener('click', () => {

    abcde ++;
    if (abcde % 2 == 1) {



        if (cur >= quizData.length) { // 문제 끝
            $(question_container).empty()
            quiz.innerHTML = `<h2>총 ${quizData.length}문제 중 ${score} 문제를 맞추셨습니다.
        </h2> <button onclick="location.reload()">Reload</button>`
            $("#quiz").css({
                backgroundImage: "url('')",
                // 빈 화면
                // backgroundColor : 'red'
                backgroundRepeat: "no-repeat",
                backgroundSize: "200px 200px",
                // 그림 크기 지정
            })


            // quiz.style.display="block"
            // /Users/nohyewon/Desktop/jokbal/o.png
            // /Users/nohyewon/Desktop/jokbal/x.png

        } else {
            if (getSelected() === quizData[cur].correct) {
                score++;
                //quiz.innerHTML = "정답입니다"
                $("#quiz").css({
                    backgroundImage: "url('./image/o.png')",
                    // backgroundColor : 'red'
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "200px 200px",
                })
                // 여기에 정답일 시 만들어야 하는 곳
                //그곳에 else 붙여서 틀렸을때 나오는거도 따로 만들고
            } else {
                // 틀렸을 때 만들어야 하는 곳
                //quiz.innerHTML = "틀렸습니다"
                $("#quiz").css({
                    // backgroundColor : 'yellow'
                    "background-image": 'url("./image/x.png")',
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "200px 200px",
                })
            }

            cur++;
            
        }
    }
    else{
        $("#quiz").css({
            backgroundImage: "url('')",
            // backgroundColor : 'red'
            backgroundRepeat: "no-repeat",
            backgroundSize: "100px 100px",
            // 그림 크기 지정
        })
        loadQuiz();
            deSelectAnswer();
    }




})

// function check() {
//     let chk1 = document.getElementsByName("check1"); // name="check1" 값 불러옴
//     let chk2 = document.getElementsByName("check2"); // name="check2" 값 불러옴
//     let chkCnt1 = 0;
//     let chkCnt2 = 0;
//     for(let i=0; i<4; i++) { 
//       if(chk1[i].checked) {
//         chkCnt1++;
//       }
//     } 
//     // 1. 체크 여부 검사
//     if(chkCnt1 == 1) {
//     alert("1개만 선택하세요");
//     } 
//     if(chkCnt1 == 1) {
//       alert("다음으로");
//     }
//   }

loadQuiz();